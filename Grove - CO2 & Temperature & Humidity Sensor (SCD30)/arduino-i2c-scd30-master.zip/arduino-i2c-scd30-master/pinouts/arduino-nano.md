# Arduino Nano Pinout SCD30 I2C

| *SCD30* | *SCD30 Pin* | *Cable Color* | *Board Pin* |
| :---: | --- | --- | --- |
| VDD | 1 | red | 3.3V |
| GND | 2 | black | GND |
| SCL | 3 | yellow | A5 |
| SDA | 4 | green | A4 |
| SEL | 7 |  | GND |


<img src="Arduino-Nano-pinout.png" width="700px">
