# Arduino Uno Pinout SCD30 I2C

| *SCD30* | *SCD30 Pin* | *Cable Color* | *Board Pin* |
| :---: | --- | --- | --- |
| VDD | 1 | red | 3.3V |
| GND | 2 | black | GND |
| SCL | 3 | yellow | D19/SCL |
| SDA | 4 | green | D18/SDA |
| SEL | 7 | blue | GND |


<img src="Arduino-Uno-Rev3-pinout.png" width="700px">
